# ktools



## 🛠️ Installation.

### Using pip


1. Open a jupyterhub notebook:
2. Run the following `pip` command:

```
!pip3.8 install
```

## 🙋 Support
Need help? Want to share a perspective? Report a bug? Ideas for collaborations? Reach out via the following channels:


## 🤝🏽 Contributing
